from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import sqlite3
import os

app = FastAPI(
    title="AgriMeta Backend API",
    description="AI-powered virtual tours and agricultural simulation backend connected to a real database.",
    version="2.0.0"
)

DB_PATH = "agri.db"

# =====================================
# DATABASE SETUP
# =====================================

def init_db():
    """Create the tours table if it doesn't exist."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tours (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            description TEXT,
            video_url TEXT
        );
    """)

    conn.commit()
    conn.close()

def seed_db():
    """Insert one sample tour row if database is empty."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM tours")
    count = cursor.fetchone()[0]

    if count == 0:
        cursor.execute("""
            INSERT INTO tours (name, description, video_url)
            VALUES (
                'Sustainable Wheat Farm – Sunrise Tour',
                'A 360° HDR tour showing irrigation, soil sensors, and crop rotation.',
                'https://example.com/video/wheat_360.mp4'
            );
        """)
        conn.commit()

    conn.close()

def get_tour_from_db(tour_id: int):
    """Fetch a tour row from SQLite."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("SELECT id, name, description, video_url FROM tours WHERE id = ?", (tour_id,))
    row = cursor.fetchone()

    conn.close()
    return row

@app.on_event("startup")
def startup():
    init_db()
    seed_db()

# =====================================
# ADVANCED STATIC METADATA
# =====================================

advanced_metadata = {
    "media": {"resolution": "8K HDR", "duration_seconds": 312},
    "simulation": {
        "weather": {
            "current": "Clear",
            "temperature_celsius": 22.4,
            "wind_speed_mps": 3.1,
            "forecast_next_hour": "Partly Cloudy"
        },
        "crop_health_score": 0.91,
        "soil_moisture_pct": 28.7,
        "pest_risk_level": "Low"
    },
    "hotspots": [
        {
            "id": 1,
            "title": "Soil Moisture Sensor",
            "type": "IoT Device",
            "coordinates": [12.4, 55.1],
            "description": "Tracks water content every 90 seconds.",
            "ai_explanation": "Optimizes irrigation using ML predictions."
        },
        {
            "id": 2,
            "title": "AI Irrigation Controller",
            "type": "Automation Panel",
            "coordinates": [40.2, 10.7],
            "description": "Cuts water waste by 27%.",
            "ai_explanation": "Uses forecasts + soil data to adjust flow."
        }
    ],
    "ai_features": {
        "narration_enabled": True,
        "recommended_topics": [
            "Climate-Resilient Farming",
            "Soil Regeneration",
            "IoT Crop Monitoring"
        ],
        "estimated_learning_time_minutes": 14
    },
    "platform_support": {
        "web": True,
        "mobile": True,
        "vr": ["Meta Quest 2", "HTC Vive", "Valve Index"],
        "ar_capability": True
    },
    "analytics": {
        "average_completion_rate": 0.82,
        "user_rating": 4.7,
        "total_visits": 13842,
        "last_updated": "2025-01-12T14:33:02Z"
    }
}

# =====================================
# GET A SINGLE TOUR
# =====================================
@app.get("/api/tours/{tour_id}")
def get_tour(tour_id: int):
    row = get_tour_from_db(tour_id)

    if not row:
        raise HTTPException(status_code=404, detail="Tour not found in database")

    base = {
        "id": row[0],
        "name": row[1],
        "description": row[2],
        "video_url": row[3],
        "source": "database",
    }

    return {**base, **advanced_metadata}

# =====================================
# LIST ALL TOURS
# =====================================
@app.get("/api/tours")
def list_tours():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, description, video_url FROM tours")
    rows = cursor.fetchall()
    conn.close()

    return [
        {
            "id": row[0],
            "name": row[1],
            "description": row[2],
            "video_url": row[3],
            "source": "database"
        }
        for row in rows
    ]

# =====================================
# CRUD HELPERS
# =====================================
def insert_tour(name: str, description: str, video_url: str):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO tours (name, description, video_url) VALUES (?, ?, ?)",
        (name, description, video_url)
    )
    conn.commit()
    new_id = cursor.lastrowid
    conn.close()
    return new_id

def update_tour(tour_id: int, name: str, description: str, video_url: str):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE tours SET name = ?, description = ?, video_url = ? WHERE id = ?",
        (name, description, video_url, tour_id)
    )
    conn.commit()
    updated = cursor.rowcount
    conn.close()
    return updated

def delete_tour(tour_id: int):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM tours WHERE id = ?", (tour_id,))
    conn.commit()
    deleted = cursor.rowcount
    conn.close()
    return deleted

# =====================================
# CREATE / UPDATE / DELETE
# =====================================
@app.post("/api/tours")
def create_tour(name: str, description: str, video_url: str):
    new_id = insert_tour(name, description, video_url)
    return {"message": "Tour created", "tour_id": new_id}

@app.put("/api/tours/{tour_id}")
def update_tour_endpoint(tour_id: int, name: str, description: str, video_url: str):
    updated = update_tour(tour_id, name, description, video_url)
    if updated == 0:
        raise HTTPException(status_code=404, detail="Tour not found")
    return {"message": "Tour updated", "tour_id": tour_id}

@app.delete("/api/tours/{tour_id}")
def delete_tour_endpoint(tour_id: int):
    deleted = delete_tour(tour_id)
    if deleted == 0:
        raise HTTPException(status_code=404, detail="Tour not found")
    return {"message": "Tour deleted", "tour_id": tour_id}

# =====================================
# AI RECOMMENDATION MODEL
# =====================================

class UserHistory(BaseModel):
    topics: list[str]

def generate_ai_recommendations(user_history: list[str]):
    recommendations = []

    if "irrigation" in user_history or "water" in user_history:
        recommendations += ["Hydroponic Greenhouse Lab", "Advanced Irrigation Management"]

    if "soil" in user_history or "sustainable" in user_history:
        recommendations += ["Soil Regeneration 101", "Cover Crop VR Experience"]

    if "technology" in user_history:
        recommendations += ["Drone Farm Mapping Simulation", "AI Crop Disease Lab"]

    if not recommendations:
        recommendations = [
            "Climate-Resilient Farming Basics",
            "Organic Farming Introduction",
            "AI in Modern Agriculture"
        ]

    return {
        "status": "success",
        "input_topics": user_history,
        "recommended_topics": recommendations,
        "ai_model": "AgriMeta-Recommendation-Engine-v0.3"
    }

@app.post("/api/ai/recommend")
def ai_recommend(data: UserHistory):
    return generate_ai_recommendations(data.topics)

# =====================================
# ROOT
# =====================================
@app.get("/")
def home():
    return {
        "message": "AgriMeta Backend API (Database + AI Active)",
        "sample_tour": "/api/tours/1",
        "ai_recommendations": "/api/ai/recommend",
        "list_all_tours": "/api/tours"
    }
