const express = require("express");
const app = express();

app.use(express.json());

let userData = {};

// simple keyword mapping
const keywordMap = {
  wheat: ["Wheat Farm Tour", "Grain Production Guide"],
  soil: ["Soil Health Exploration"],
  irrigation: ["Irrigation Systems Tour"],
  farming: ["General Farm Experience"]
};

// normalize input
function normalizeQuery(query) {
  return query.toLowerCase().trim();
}

// TRACK USER SEARCH
app.post("/track", (req, res) => {
  const { userId, query } = req.body;

  if (!userId || !query) {
    return res.status(400).json({ error: "Missing userId or query" });
  }

  const cleanQuery = normalizeQuery(query);

  if (!userData[userId]) {
    userData[userId] = [];
  }

  const entry = {
    query: cleanQuery,
    timestamp: Date.now()
  };

  userData[userId].push(entry);

  // terminal log (what you wanted)
  console.log(`[TRACK] User ${userId}: ${cleanQuery}`);

  // response with full info
  res.json({
    message: "Search tracked successfully",
    stored: entry,
    totalSearches: userData[userId].length
  });
});

// GET RECOMMENDATIONS
app.get("/recommendations/:userId", (req, res) => {
  const history = userData[req.params.userId] || [];

  let scores = {};

  history.forEach(item => {
    Object.keys(keywordMap).forEach(keyword => {
      if (item.query.includes(keyword)) {
        keywordMap[keyword].forEach(rec => {
          scores[rec] = (scores[rec] || 0) + 1;
        });
      }
    });
  });

  const sorted = Object.keys(scores).sort((a, b) => scores[b] - scores[a]);

  const recommendations =
    sorted.length > 0
      ? sorted.slice(0, 3)
      : ["Popular Farm Tour", "Beginner Agriculture Guide"];

  console.log(`[RECOMMEND] User ${req.params.userId}:`, recommendations);

  res.json({ recommendations });
});

// INSIGHTS
app.get("/insights/:userId", (req, res) => {
  const history = userData[req.params.userId] || [];
  let keywordCount = {};

  history.forEach(item => {
    Object.keys(keywordMap).forEach(keyword => {
      if (item.query.includes(keyword)) {
        keywordCount[keyword] = (keywordCount[keyword] || 0) + 1;
      }
    });
  });

  res.json({ interests: keywordCount });
});

// RESET USER DATA
app.delete("/reset/:userId", (req, res) => {
  delete userData[req.params.userId];
  res.json({ message: "User data reset" });
});

// ROOT TEST
app.get("/", (req, res) => {
  console.log("ROOT HIT");
  res.send("server alive");
});

// START SERVER
app.listen(3000, () => {
  console.log("SERVER STARTED");
});