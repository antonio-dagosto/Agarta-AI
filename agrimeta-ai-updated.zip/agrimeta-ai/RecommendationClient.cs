using System;
using System.Collections;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;
using TMPro;

public class RecommendationClient : MonoBehaviour
{
    [Header("API Settings")]
    [SerializeField] private string baseUrl = "http://localhost:3000";

    [Header("UI")]
    [SerializeField] private TMP_InputField queryInput;
    [SerializeField] private TMP_Text outputText;

    // Hardcoded user ID since you removed that input
    private string userId = "1";

    [Serializable]
    private class TrackRequest
    {
        public string userId;
        public string query;
    }

    [Serializable]
    private class StoredQuery
    {
        public string userId;
        public string query;
        public long timestamp;
    }

    [Serializable]
    private class TrackResponse
    {
        public string message;
        public StoredQuery stored;
        public int totalSearches;
    }

    [Serializable]
    private class RecommendationItem
    {
        public string id;
        public string title;
        public string type;
        public string[] tags;
    }

    [Serializable]
    private class RecommendationResponse
    {
        public RecommendationItem[] recommendations;
    }

    // 🔘 This is the function your Submit button calls
    public void OnSubmitButton()
    {
        string query = queryInput.text.Trim();

        if (string.IsNullOrEmpty(query))
        {
            outputText.text = "Please enter a search query.";
            return;
        }

        StartCoroutine(TrackAndRecommend(query));
    }

    // 🔁 Track search → then get recommendations
    private IEnumerator TrackAndRecommend(string query)
    {
        TrackRequest requestData = new TrackRequest
        {
            userId = userId,
            query = query
        };

        string json = JsonUtility.ToJson(requestData);
        byte[] bodyRaw = Encoding.UTF8.GetBytes(json);

        using (UnityWebRequest request = new UnityWebRequest($"{baseUrl}/track", "POST"))
        {
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");

            yield return request.SendWebRequest();

            if (request.result != UnityWebRequest.Result.Success)
            {
                outputText.text = "Error: " + request.error;
                yield break;
            }
        }

        yield return StartCoroutine(GetRecommendations());
    }

    // 📊 Get recommendations
    private IEnumerator GetRecommendations()
    {
        using (UnityWebRequest request = UnityWebRequest.Get($"{baseUrl}/recommendations/{userId}"))
        {
            yield return request.SendWebRequest();

            if (request.result != UnityWebRequest.Result.Success)
            {
                outputText.text = "Error: " + request.error;
                yield break;
            }

            RecommendationResponse response =
                JsonUtility.FromJson<RecommendationResponse>(request.downloadHandler.text);

            if (response == null || response.recommendations == null || response.recommendations.Length == 0)
            {
                outputText.text = "No recommendations found.";
                yield break;
            }

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Recommended:");

            foreach (var item in response.recommendations)
            {
                sb.AppendLine("- " + item.title);
            }

            outputText.text = sb.ToString();
        }
    }
}