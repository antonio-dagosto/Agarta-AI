const express = require("express");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Serve the frontend from the same folder as server.js
app.use(express.static(__dirname));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// In-memory storage
const userData = {};
const feedbackData = {};

// Content catalog
const contentCatalog = [
  
  {
  id: "tour-greenhouse-001",
  title: "Greenhouse Farming Tour",
  type: "tour",
  tags: ["greenhouse", "plants", "indoor farming"]
},
{
  id: "tour-orchard-001",
  title: "Orchard Harvest Tour",
  type: "tour",
  tags: ["orchard", "fruit", "trees", "harvest"]
},
{
  id: "tour-dairy-001",
  title: "Dairy Farm Tour",
  type: "tour",
  tags: ["dairy", "cows", "milk", "livestock"]
},
{
  id: "tour-rice-001",
  title: "Rice Field Cultivation Tour",
  type: "tour",
  tags: ["rice", "paddy", "water farming"]
},
{
  id: "sim-weather-001",
  title: "Weather Impact Simulation",
  type: "simulation",
  tags: ["weather", "rain", "drought", "climate"]
},
{
  id: "sim-fertilizer-001",
  title: "Fertilizer Management Simulation",
  type: "simulation",
  tags: ["fertilizer", "nutrients", "soil"]
},
{
  id: "sim-harvest-001",
  title: "Harvest Optimization Simulation",
  type: "simulation",
  tags: ["harvest", "yield", "efficiency"]
},
{
  id: "sim-irrigation-advanced-001",
  title: "Advanced Irrigation Techniques",
  type: "simulation",
  tags: ["irrigation", "drip", "water efficiency"]
}


];

// Helpers
function normalizeQuery(query) {
  return String(query).toLowerCase().replace(/[^\w\s]/g, "").trim();
}

function storeUserQuery(userId, query) {
  if (!userData[userId]) userData[userId] = [];
  userData[userId].push({ query, timestamp: Date.now() });
}

function getHistory(userId) {
  return userData[userId] || [];
}

function getRecentQueries(userId, limit = 5) {
  return getHistory(userId).slice(-limit).map(q => q.query);
}

function getAllQueries(userId) {
  return getHistory(userId).map(q => q.query);
}

// Feedback helpers
function ensureFeedback(userId) {
  if (!feedbackData[userId]) feedbackData[userId] = {};
}

function recordFeedback(userId, contentId, action, rating = null) {
  ensureFeedback(userId);

  if (!feedbackData[userId][contentId]) {
    feedbackData[userId][contentId] = {
      views: 0,
      clicks: 0,
      ratings: []
    };
  }

  const entry = feedbackData[userId][contentId];

  if (action === "view") entry.views += 1;
  if (action === "click") entry.clicks += 1;
  if (action === "rate" && typeof rating === "number") {
    entry.ratings.push(rating);
  }
}

function getUserFeedback(userId, contentId) {
  return feedbackData[userId]?.[contentId] || {
    views: 0,
    clicks: 0,
    ratings: []
  };
}

// Recommendation scoring
function scoreContent(userId, content) {
  const recent = getRecentQueries(userId);
  const all = getAllQueries(userId);

  let score = 0;

  // Recent searches matter more
  recent.forEach(q => {
    content.tags.forEach(tag => {
      if (q.includes(tag)) score += 3;
    });
  });

  // Older searches still count
  all.forEach(q => {
    content.tags.forEach(tag => {
      if (q.includes(tag)) score += 1;
    });
  });

  // Feedback boosts
  const feedback = getUserFeedback(userId, content.id);
  score += feedback.views * 0.5;
  score += feedback.clicks * 1.5;

  if (feedback.ratings.length > 0) {
    const avg =
      feedback.ratings.reduce((a, b) => a + b, 0) /
      feedback.ratings.length;
    score += avg;
  }

  return score;
}

function recommendContent(userId) {
  const scored = contentCatalog
    .map(item => ({
      ...item,
      score: scoreContent(userId, item)
    }))
    .sort((a, b) => b.score - a.score);

  const valid = scored.filter(i => i.score > 0);

  return valid.length > 0
    ? valid.slice(0, 3).map(({ score, ...rest }) => rest)
    : contentCatalog.slice(0, 3);
}

// Routes

app.get("/content", (req, res) => {
  res.json({ contentCatalog });
});

app.post("/track", (req, res) => {
  try {
    const { userId, query } = req.body;

    if (!userId || !query) {
      return res.status(400).json({ error: "Missing data" });
    }

    const clean = normalizeQuery(query);
    storeUserQuery(userId, clean);

    res.json({
      message: "Search tracked successfully",
      stored: {
        userId,
        query: clean,
        timestamp: Date.now()
      },
      totalSearches: getHistory(userId).length
    });
  } catch (error) {
    console.error("Tracking error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.post("/feedback", (req, res) => {
  try {
    const { userId, contentId, action, rating } = req.body;

    if (!userId || !contentId || !action) {
      return res.status(400).json({ error: "Missing fields" });
    }

    if (!["view", "click", "rate"].includes(action)) {
      return res.status(400).json({ error: "Invalid action" });
    }

    if (
      action === "rate" &&
      (typeof rating !== "number" || rating < 1 || rating > 5)
    ) {
      return res.status(400).json({ error: "Rating must be between 1 and 5" });
    }

    recordFeedback(userId, contentId, action, rating);

    res.json({
      message: "Feedback saved",
      feedback: getUserFeedback(userId, contentId)
    });
  } catch (error) {
    console.error("Feedback error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get("/recommendations/:userId", (req, res) => {
  try {
    const recs = recommendContent(req.params.userId);
    res.json({ recommendations: recs });
  } catch (error) {
    console.error("Recommendation error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get("/profile/:userId", (req, res) => {
  try {
    const history = getHistory(req.params.userId);
    const recommended = recommendContent(req.params.userId);

    res.json({
      totalSearches: history.length,
      lastSearch: history.at(-1)?.query || null,
      recommendedTitles: recommended.map(item => item.title)
    });
  } catch (error) {
    console.error("Profile error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get("/status", (req, res) => {
  const activeUsers = Object.keys(userData).length;
  const totalQueries = Object.values(userData).reduce(
    (sum, history) => sum + history.length,
    0
  );

  res.json({
    system: "AgriMeta Recommendation Engine",
    activeUsers,
    totalQueries,
    totalContentItems: contentCatalog.length
  });
});

app.delete("/reset/:userId", (req, res) => {
  const history = getHistory(req.params.userId);
  delete userData[req.params.userId];
  delete feedbackData[req.params.userId];

  res.json({
    message: "User reset",
    deletedEntries: history.length
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});