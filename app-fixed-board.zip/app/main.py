from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional

from app.db import (
    init_db,
    seed_data,
    get_all_tours,
    get_tour_from_db,
    create_tour_db,
    update_tour_db,
    delete_tour_db,
    get_analytics
)

app = FastAPI(title="AgriMeta Backend API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Tour(BaseModel):
    id: int
    name: str
    description: str
    video_url: str
    views: int
    source: str

class CreateTour(BaseModel):
    name: str
    description: str
    video_url: str

class AnalyticsResponse(BaseModel):
    total_tours: int
    total_views: int
    most_viewed_tour: Optional[dict]
    monthly_growth: list

@app.on_event("startup")
def startup():
    init_db()
    seed_data()

@app.get("/api/tours", response_model=List[Tour])
def list_tours():
    rows = get_all_tours()
    return [
        {
            "id": r[0],
            "name": r[1],
            "description": r[2],
            "video_url": r[3],
            "views": r[4],
            "source": "database"
        }
        for r in rows
    ]

@app.get("/api/tours/{tour_id}", response_model=Tour)
def get_tour(tour_id: int):
    row = get_tour_from_db(tour_id)
    if not row:
        raise HTTPException(status_code=404, detail="Tour not found")

    return {
        "id": row[0],
        "name": row[1],
        "description": row[2],
        "video_url": row[3],
        "views": row[4],
        "source": "database"
    }

@app.post("/api/tours")
def create_tour(tour: CreateTour):
    create_tour_db(tour.name, tour.description, tour.video_url)
    return {"message": "Tour created"}

@app.put("/api/tours/{tour_id}")
def edit_tour(tour_id: int, tour: CreateTour):
    updated = update_tour_db(tour_id, tour.name, tour.description, tour.video_url)
    if updated == 0:
        raise HTTPException(status_code=404, detail="Tour not found")
    return {"message": "Tour updated"}

@app.delete("/api/tours/{tour_id}")
def delete_tour(tour_id: int):
    deleted = delete_tour_db(tour_id)
    if deleted == 0:
        raise HTTPException(status_code=404, detail="Tour not found")
    return {"message": "Tour deleted"}

@app.get("/api/analytics", response_model=AnalyticsResponse)
def analytics():
    return get_analytics()