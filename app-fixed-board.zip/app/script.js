const API_BASE = "http://127.0.0.1:8000/api";

document.addEventListener("DOMContentLoaded", init);

function init() {
    loadTours();
    loadAnalytics();
}

async function loadTours() {
    const res = await fetch(`${API_BASE}/tours`, { cache: "no-store" });
    const tours = await res.json();

    const container = document.getElementById("tours");
    container.innerHTML = "";

    tours.forEach(t => {
        const div = document.createElement("div");
        div.style.border = "1px solid #ccc";
        div.style.padding = "15px";
        div.style.margin = "15px 0";
        div.style.borderRadius = "8px";

        div.innerHTML = `
            <h3>${t.name}</h3>
            <p>${t.description}</p>
            <p><strong>Views: ${t.views}</strong></p>

            <video width="100%" controls>
                <source src="${t.video_url}" type="video/mp4">
                Your browser does not support the video tag.
            </video>

            <br><br>

            <button onclick="viewTour(${t.id})">View</button>
        `;

        container.appendChild(div);
    });
}

async function viewTour(id) {
    await fetch(`${API_BASE}/tours/${id}`, { cache: "no-store" });
    await loadTours();
    await loadAnalytics();
}

async function loadAnalytics() {
    const res = await fetch(`${API_BASE}/analytics`, { cache: "no-store" });
    const data = await res.json();

    document.getElementById("totalTours").textContent = data.total_tours;
    document.getElementById("totalViews").textContent = data.total_views;

    if (data.most_viewed_tour) {
        document.getElementById("mostViewed").textContent =
            `${data.most_viewed_tour.name} (${data.most_viewed_tour.views} views)`;
    } else {
        document.getElementById("mostViewed").textContent = "None";
    }
}