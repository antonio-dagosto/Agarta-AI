import sqlite3
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "agri.db")


def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tours (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT NOT NULL,
            video_url TEXT,
            views INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    """)

    conn.commit()
    conn.close()


def seed_data():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM tours;")
    if cursor.fetchone()[0] == 0:
        cursor.execute("""
            INSERT INTO tours (name, description, video_url)
            VALUES (
                'Sustainable Wheat Farm – Sunrise Tour',
                'A 360° HDR tour showing irrigation and crop rotation.',
                'https://example.com/video.mp4'
            );
        """)
        conn.commit()

    conn.close()


def get_all_tours():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id, name, description, video_url, views
        FROM tours;
    """)

    rows = cursor.fetchall()
    conn.close()
    return rows


def get_tour_from_db(tour_id: int):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute(
        "UPDATE tours SET views = views + 1 WHERE id = ?",
        (tour_id,)
    )
    conn.commit()

    cursor.execute("""
        SELECT id, name, description, video_url, views
        FROM tours WHERE id = ?
    """, (tour_id,))

    row = cursor.fetchone()
    conn.close()
    return row


def create_tour_db(name, description, video_url):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute(
        "INSERT INTO tours (name, description, video_url) VALUES (?, ?, ?)",
        (name, description, video_url)
    )

    conn.commit()
    conn.close()


def update_tour_db(tour_id, name, description, video_url):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
        UPDATE tours
        SET name = ?, description = ?, video_url = ?
        WHERE id = ?
    """, (name, description, video_url, tour_id))

    conn.commit()
    updated = cursor.rowcount
    conn.close()
    return updated


def delete_tour_db(tour_id):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("DELETE FROM tours WHERE id = ?", (tour_id,))
    conn.commit()

    deleted = cursor.rowcount
    conn.close()
    return deleted


def get_analytics():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM tours;")
    total_tours = cursor.fetchone()[0]

    cursor.execute("SELECT SUM(views) FROM tours;")
    result = cursor.fetchone()[0]
    total_views = result if result else 0

    cursor.execute("""
        SELECT name, views
        FROM tours
        ORDER BY views DESC
        LIMIT 1;
    """)
    top_row = cursor.fetchone()

    most_viewed = (
        {"name": top_row[0], "views": top_row[1]}
        if top_row else None
    )

    conn.close()

    return {
        "total_tours": total_tours,
        "total_views": total_views,
        "most_viewed_tour": most_viewed,
        "monthly_growth": []
    }